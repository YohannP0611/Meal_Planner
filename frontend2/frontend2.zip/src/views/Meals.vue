<template>
  <div class="meal">
    <h1>This is the meal page !</h1>
  </div>
</template>
